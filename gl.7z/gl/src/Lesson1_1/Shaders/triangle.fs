#version 120

varying lowp vec4 col;

void main() {
   gl_FragColor = col;
}